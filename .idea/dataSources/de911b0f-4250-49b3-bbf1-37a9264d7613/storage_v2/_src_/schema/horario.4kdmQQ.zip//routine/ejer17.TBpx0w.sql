create
  definer = root@localhost function ejer17(curso char(2), oferta char(3)) returns varchar(20)
BEGIN
DECLARE tutor VARCHAR(20) DEFAULT 'No hay ningun tutor';
SELECT nombre FROM profesor p, curso c WHERE codProf = codTutor AND codCurso = curso AND codOe = oferta INTO tutor;
RETURN tutor;
END;

