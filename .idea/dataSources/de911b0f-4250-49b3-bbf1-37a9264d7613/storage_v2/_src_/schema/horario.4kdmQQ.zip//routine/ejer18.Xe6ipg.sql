create
  definer = root@localhost procedure ejer18(IN pCurso char(2), IN pOferta char(3), OUT pHoras varchar(6),
                                            OUT pNombre varchar(20), IN pAsig varchar(6))
BEGIN
SELECT a.horasSemanales, p.nombre FROM asignatura a JOIN reparto r ON r.codAsig = a.codAsig JOIN profesor p ON p.codProf = r.codProf WHERE r.codCurso = pCurso AND r.codOe = pOferta AND r.codAsig = pAsig INTO pHoras, pNombre;
END;

